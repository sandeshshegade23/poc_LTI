﻿using System;
using Document_repository.Models;
using Microsoft.EntityFrameworkCore;

namespace Document_repository.Data
{
    public class AppdbContext : DbContext
    {
        public AppdbContext(DbContextOptions<AppdbContext> options)
        : base(options)
        {
        }

        public DbSet<Document> Documents { get; set; }
    }
}
