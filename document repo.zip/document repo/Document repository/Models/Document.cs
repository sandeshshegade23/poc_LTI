﻿using System.ComponentModel.DataAnnotations;

namespace Document_repository.Models
{
    public class Document
    {
        public int Id { get; set; }

        [Required]
        public string DocName { get; set; }

        public string DocPath { get; set; }

        public string Name { get; set; }

        public string DocCode { get; set; }

        public DateTime UploadedOn { get; set; }
    }
}


