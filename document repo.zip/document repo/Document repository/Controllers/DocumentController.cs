﻿using System;
using Document_repository.Data;
using Document_repository.Models;
using Microsoft.AspNetCore.Mvc;

namespace Document_repository.Controllers
{
    public class DocumentController : Controller
    {

        private readonly AppdbContext _context;
        private readonly IWebHostEnvironment _env;

        public DocumentController(AppdbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Create()
        {
            return View();
        }

        

        public async Task<IActionResult> Download(int id)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc == null) return NotFound();

            var path = Path.Combine(_env.WebRootPath, doc.DocPath.TrimStart('/'));
            return PhysicalFile(path, "application/octet-stream", doc.DocName);
        }

        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
                return NotFound();

            var document = await _context.Documents.FindAsync(id);
            if (document == null)
                return NotFound();

            return View(document);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, IFormFile file, string name, string doccode)
        {
            var document = await _context.Documents.FindAsync(id);
            if (document == null)
                return NotFound();

            // Update name and code
            document.Name = name;
            document.DocCode = doccode;

            // If user uploads new file
            if (file != null && file.Length > 0)
            {
                // 5 MB validation
                if (file.Length > 5 * 1024 * 1024)
                {
                    ModelState.AddModelError("", "File size must be less than 5 MB");
                    return View(document);
                }

                string uploads = Path.Combine(_env.WebRootPath, "uploads");
                Directory.CreateDirectory(uploads);

                string fileName = Path.GetFileName(file.FileName);
                string filePath = Path.Combine(uploads, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                document.DocName = fileName;
                document.DocPath = "/Uploads/" + fileName;
                document.UploadedOn = DateTime.Now;
                
            }

            _context.Update(document);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }



        public async Task<IActionResult> Delete(int id)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc != null)
            {
                _context.Documents.Remove(doc);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    

        public IActionResult Index()
        {
            var documents = _context.Documents
                            .OrderByDescending(d => d.UploadedOn)
                            .ToList();

            return View(documents);
            //return View();
        }


        [HttpPost]
        public async Task<IActionResult> Create(IFormFile file, string name,string doccode)
        {
            string extension = Path.GetExtension(file.FileName);

            string[] allowedExtensions = { ".pdf", ".xls", ".xlsx" };

            if (!allowedExtensions.Contains(extension))
            {
                ModelState.AddModelError("", "Only PDF or Excel files are allowed");
                return View();
            }

            if (file == null || file.Length == 0)
            {
                ModelState.AddModelError("", "Please select a file");
                return View();
            }

            if (file.Length > 5 * 1024 * 1024)
            {
                ModelState.AddModelError("", "File size must be less than 5 MB");
                return View();
            }

            string uploads = Path.Combine(_env.WebRootPath, "Uploads");
            Directory.CreateDirectory(uploads);

            string fileName = Path.GetFileName(file.FileName);
            string filePath = Path.Combine(uploads, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var document = new Document
            {
                DocName = fileName,
                DocPath = "/Uploads/" + fileName,
                Name = name,
                DocCode =doccode,
                UploadedOn = DateTime.Now
            };

            _context.Documents.Add(document);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


    }
}
