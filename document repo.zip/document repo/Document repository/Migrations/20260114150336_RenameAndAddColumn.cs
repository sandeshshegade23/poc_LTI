﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Document_repository.Migrations
{
    /// <inheritdoc />
    public partial class RenameAndAddColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Description",
                table: "Documents",
                newName: "Name");

            migrationBuilder.AddColumn<string>(
                name: "DocCode",
                table: "Documents",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DocCode",
                table: "Documents");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Documents",
                newName: "Description");
        }
    }
}
